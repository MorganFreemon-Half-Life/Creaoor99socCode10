<h1 class="header">creaoo99soc</h1>
<h3 class="header">Register: </h3>
<title>Register</title>
<form action="register_create.php" method="POST">
    <input class="box" type="text" value="Username" name="reg-username">
    <br>
    <br>
    <input class="box" type="text" value="Password" name="reg-password">
    <br>
    <br>
    <input class="button" type="submit" value="Register">
</form>
<link href="style.css" rel="stylesheet" type="text/css" />