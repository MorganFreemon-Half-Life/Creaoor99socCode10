<?php
echo "<h1>Welcome to completly PHP echo page!</h1>";
echo "This was made in PHP :)!";

?>