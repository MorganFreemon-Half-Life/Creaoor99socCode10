<link href="style.css" rel="stylesheet" type="text/css" />
<body>
    <h1 class="header">Crear99soc's home</h1>
    <br>
    <h3><a class="button" href="index.php">Login Screen</a></h3>
    <h3><a class="button" href="notepad.php">Notepad</a></h3>
    <h3><a class="button" href="https://creaoor99soc.000webhostapp.com/forum">Forum</a></h3>
</body>