<link href="style.css" rel="stylesheet" type="text/css" />
<title>Login</title>
<h1 class="header">creaoor99soc (MADE BY CABAGE)</h1>
<h3 class="header">Login: </h3>
<form action="login_check.php" method="POST">
    <input class="box" type="text" value="Username" name="login-username">
    <br>
    <br>
    <input class="box" type="text" value="Password" name="login-password">
    <br>
    <br>
    <input class="button" type="submit" value="Login">
</form>
<h5 class="header">Not registed? <a href="register.php">Register now (FOR FREE)!</a></h5>