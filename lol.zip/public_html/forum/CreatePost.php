<h1>Create A Post</h1>
<form action="crp.php" method="POST">
    <center>
    <input name="post-title" type="text" value="Title"></input>
    <br>
    <br>

    <textarea name="post-contents" rows="50" cols="100"></textarea>
    <br>
    <input type="submit" text="Post"></input>
    </center>
</form>
