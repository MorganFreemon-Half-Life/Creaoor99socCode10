<link href="style.css" rel="stylesheet" type="text/css" />
<header>
    <h3 class="header">creaoor99soc</h3>
</header>
<h3><a class="button" href="home.php">Home</a></h3>
<br>
<h3><a class="button" href="https://github.com/MorganFreem0n/creaoor99soc?ref=creaoor99soc.000webhostapp.com">Source Code</a></h3>
<?php
// This file is used for the host
?>

