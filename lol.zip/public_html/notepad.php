<link href="style.css" rel="stylesheet" type="text/css" />
<center>
    <body>
        <h1 class="header">Notepad</h1>
        <br>
        <br>
        <textarea class="box" rows="30" cols="100"></textarea>
        <br>
        <br>
        <h3><a class="button" href="index.php">Back</a></h3>
    </body>
</center>